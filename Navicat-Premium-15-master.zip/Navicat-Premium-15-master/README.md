### 下载
* [Navicat15 官网下载地址](http://www.navicat.com.cn/download/navicat-premium)  
* 注册机在此项目中下载到本地即可  
* [XAMPP 官网下载](https://sourceforge.net/projects/xampp/files/)
### 简单的使用说明

#### 注意事项 
* 仅供学习使用，学习使用，学习使用，还是要支持正版
* 激活的时候断网！断网！断网！
* 先打开注册机 patch(patch的路径就是你安装navicat根目录下navicat.exe文件选中点击path即可)完出现navicat.exe -x64 -> cracked 再继续选择下面的操作  
**！！！先打开注册机patch成功后再打开navicat，切记切记切记！！**    
* 假如没安装成功检查是否以前有安装过，清理安装记录，清理注册表之类的
***
#### ！！！假如出这样的错大致原因  

![image](https://user-images.githubusercontent.com/21699695/117238464-84ea3600-ae5f-11eb-85a7-1dc648bc1bd3.png)

* 注册机没patch完就打开了Navicat
* 先退出所有杀毒软件，再打开注册机

### 简单步骤

* 1，License里选中Enterprise、在Produce里选择Premium、在Languages里选择Simplified Chinese(简体中文)  

 ![image](https://user-images.githubusercontent.com/21699695/117237744-253f5b00-ae5e-11eb-8852-e3dda6ee81d6.png)  
 
* 2，选择Site License  

 ![image](https://user-images.githubusercontent.com/21699695/117237814-47d17400-ae5e-11eb-8580-b17948158cdd.png)  
 
* 3，点击Generate按钮就会生成一个许可证秘钥，将许可证秘钥复制后就打开Navicat Premium 15  

![image](https://user-images.githubusercontent.com/21699695/117237869-6899c980-ae5e-11eb-8ca0-772e35c0d519.png)  

* 4，打开Navicat Premium 15，点击注册  

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/117237941-8cf5a600-ae5e-11eb-82f4-4b7c168ec17b.png" alt="Editor" width="500">
</div>

* 5，粘贴秘钥，然后点击激活按钮  

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/117237989-abf43800-ae5e-11eb-8d73-23c0f01a4720.png" alt="Editor" width="500">
</div>

* 6，在弹出的界面选择手动激活  

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/117238026-b6163680-ae5e-11eb-8ff5-38661aa402aa.png" alt="Editor" width="500">
</div>

* 7，将请求码粘贴到注册机Request Code框中（完整过程看图） 

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/117238049-c7f7d980-ae5e-11eb-80a5-d5545ab6a4d4.png" alt="Editor" width="500">
</div>

* 8，点击激活页面的激活弹出（说明激活成功）  
  
<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/117238063-ce865100-ae5e-11eb-83d8-870e837517d8.png" alt="Editor" width="200">
</div>

**强烈推荐福利！！！每天免费领取饿了么，美团外卖红包（买菜，点美食都可以）**

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/140758752-182a4db2-ec40-4154-a090-4aba56583862.jpg" alt="Editor" width="200">
</div>

**互相学习交流**

<div align="left">
  <img src="https://user-images.githubusercontent.com/21699695/123603292-4f911180-d82c-11eb-809b-9c9f6232ba04.png" alt="Editor" width="200">
</div>

> 恭喜，激活成功啦！！如果经济允许，还是希望可以支持正版！！！  
> 附上购买地址http://www.navicat.com.cn/download/navicat-premium
